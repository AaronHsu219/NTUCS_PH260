<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>課堂練習3-1</title>
</head>
<?php 
// 註解：徐志宏 時間:2015/8/28 PM09:06
$hello = '大家好！';
echo $hello;
 ?>
<body>
</body>
</html>