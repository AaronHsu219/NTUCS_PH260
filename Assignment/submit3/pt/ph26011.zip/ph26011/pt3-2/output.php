<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>output</title>
</head>
<body>
<?php
echo "國文成績：".$_POST['var_Ch']."<br>";
echo "數學成績：".$_POST['var_Math']."<br>";
echo "英文成績：".$_POST['var_Eng']."<br>";
?>
</body>
</html>