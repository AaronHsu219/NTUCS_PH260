<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>user</title>
</head>

<?php
$user = array(
    'allan',
    'bill',
    'cindy',
    'david'
);

$userData['allan'] = array(
    'password' => '1234',
    'email' => 'allan@csie.org'
);

$userData['bill'] = array(
    'password' => '5678',
    'email' => 'bill@ntu.edu.tw'
);

$userData['cindy'] = array(
    'password' => '0000',
    'email' => 'cindy@csie.tw'
);

$userData['david'] = array(
    'password' => '1111',
    'email' => 'david@gamil.com'
);

?>

<body>
</body>
</html>