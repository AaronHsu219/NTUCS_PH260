<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>PT5-1</title>
</head>

<body>

<form method="POST" action="login.php">

<p>ID:  
  <input name="ID">
</p>
<p>PW:  
  <input name="PW">
</p>
<p>
  <input type="submit" value="送出">
</p>

</form>

</body>
</html>